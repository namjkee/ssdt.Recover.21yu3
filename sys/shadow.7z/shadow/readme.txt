========================================================================
       Windows Driver Model: shadow
========================================================================


QuickSYS has created this shadow SYS for you.  

This file contains a summary of what you will find in each of the files that
make up your wpsman application.

shadow.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

shadow.c
    This is the main SYS source file.

shadow.h
    This file contains your SYS definition.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.


/////////////////////////////////////////////////////////////////////////////
